package com.example.my.second.app;

import com.example.my.second.app.DB.*;

public class AddGoal extends android.app.Activity {
	
	private static final String TEAM_BLU = "Team BLU";
	private static final String TEAM_RED = "Team RED";
	
    @Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
    	final AddGoal self = this;
        
        setContentView(R.layout.activity_add_goal);
        getActionBar().setDisplayHomeAsUpEnabled(true);

        android.widget.Spinner team = (android.widget.Spinner) findViewById(R.id.spinner_team);
        team.setAdapter(new android.widget.ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,
        		new String[] {TEAM_BLU, TEAM_RED}));
        
        team.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int pos, long id) {
				android.widget.Spinner team = (android.widget.Spinner) findViewById(R.id.spinner_team);
				android.widget.Spinner player = (android.widget.Spinner) findViewById(R.id.spinner_player);
				android.widget.Spinner assist1 = (android.widget.Spinner) findViewById(R.id.spinner_assist_1);
		        android.widget.Spinner assist2 = (android.widget.Spinner) findViewById(R.id.spinner_assist_2);
		        
		        java.util.List<Player> players = null;
		        
				if (team.getSelectedItem().toString().equals(TEAM_BLU)) {
					players = DB.getInstance().playersOnIce(DB.TEAMBLU);
				} else if (team.getSelectedItem().toString().equals(TEAM_RED)) {
					players = DB.getInstance().playersOnIce(DB.TEAMRED);
				}
				
				player.setAdapter(new android.widget.ArrayAdapter<Player>(self, android.R.layout.simple_spinner_item, players));
				assist1.setAdapter(new android.widget.ArrayAdapter<Player>(self, android.R.layout.simple_spinner_item, players));
				assist2.setAdapter(new android.widget.ArrayAdapter<Player>(self, android.R.layout.simple_spinner_item, players));
			}
			@Override
			public void onNothingSelected(android.widget.AdapterView<?> arg0) { }
        });
    }
    
    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
            	android.support.v4.app.NavUtils.navigateUpFromSameTask(this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    public void save(android.view.View view) {
		android.widget.Spinner player = (android.widget.Spinner) findViewById(R.id.spinner_player);
		android.widget.Spinner assist1 = (android.widget.Spinner) findViewById(R.id.spinner_assist_1);
        android.widget.Spinner assist2 = (android.widget.Spinner) findViewById(R.id.spinner_assist_2);
        android.widget.CheckBox assist1CheckBox = (android.widget.CheckBox) findViewById(R.id.check_box_asssist_1);
        android.widget.CheckBox assist2CheckBox = (android.widget.CheckBox) findViewById(R.id.check_box_asssist_2);
        
        DB.getInstance().addGoal((Player) player.getSelectedItem(), assist1CheckBox.isChecked() ? (Player) assist1.getSelectedItem() : null, assist1CheckBox.isChecked() ? (Player) assist2.getSelectedItem() : null);
        finish();
    }
}
