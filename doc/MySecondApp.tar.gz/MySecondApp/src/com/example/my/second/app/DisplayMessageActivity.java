package com.example.my.second.app;

import com.example.my.second.app.DB.DB;
import com.example.my.second.app.DB.Player;

import android.os.Bundle;

public class DisplayMessageActivity extends MainActivityImpl {
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.activity_display_message);
        updatePeriodCounter();
    }
    
    public void nextPeriod(android.view.View view) {
    	DB.getInstance().nextPeriod();
    	if (DB.getInstance().isGameFinished()) {
    		String result = "Stars:\n";
    		int i = 1;
    		
    		for (Player p : DB.getInstance().getTop())
    			result += i++ + " : " + (p != null ? p.name : "") + "\n";
    		
        	android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        	builder.setTitle((DB.getInstance().getWinner() == DB.TEAMBLU ? "BLU" : "RED") + " won!!!");
        	builder.setMessage(result);
        	android.app.AlertDialog dialog = builder.create();
        	dialog.show();
    		
    		DB.getInstance().newGame();
    	}
    	
    	updatePeriodCounter();
    }
    
    private void updatePeriodCounter() {
    	android.widget.TextView editText = (android.widget.TextView) findViewById(R.id.edit_current_period);
    	editText.setText(getString(R.string.current_period) + DB.getInstance().getPeriod());
    	
    	updatePeriod();
    }
    
    public void addGoal(android.view.View view) {
    	android.content.Intent intent = new android.content.Intent(this, AddGoal.class);
		startActivity(intent);
		updateScores();
    }
    
    public void showGoals(android.view.View view) {
    	String str = "";
    	for(String s : DB.getInstance().getGoals())
    		str += s + "\n";
    	
    	android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
    	builder.setTitle("Goals");
    	builder.setMessage(str);
    	android.app.AlertDialog dialog = builder.create();
    	dialog.show();
    }
}
