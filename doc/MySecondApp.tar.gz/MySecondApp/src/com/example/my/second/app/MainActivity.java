package com.example.my.second.app;

import com.example.my.second.app.R;
import com.example.my.second.app.DB.DB;
import com.example.my.second.app.DB.Player;

public class MainActivity extends MainActivityImpl {

	private static int currentTeam = DB.TEAMBLU;

	@Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        java.util.List<Player> players = DB.getInstance().getAllPlayers().get(MainActivity.currentTeam);
        
        // There is no break statement on purpose. Don't add any.
        switch (players.size()) {
	        case 5: loadPlayer(players.get(4), R.id.edit_player_number_5, R.id.edit_player_first_name_5, R.id.edit_player_last_name_5, R.id.check_box_on_ice_5);
	        case 4: loadPlayer(players.get(3), R.id.edit_player_number_4, R.id.edit_player_first_name_4, R.id.edit_player_last_name_4, R.id.check_box_on_ice_4);
	        case 3: loadPlayer(players.get(2), R.id.edit_player_number_3, R.id.edit_player_first_name_3, R.id.edit_player_last_name_3, R.id.check_box_on_ice_3);
	        case 2: loadPlayer(players.get(1), R.id.edit_player_number_2, R.id.edit_player_first_name_2, R.id.edit_player_last_name_2, R.id.check_box_on_ice_2);
	        case 1: loadPlayer(players.get(0), R.id.edit_player_number_1, R.id.edit_player_first_name_1, R.id.edit_player_last_name_1, R.id.check_box_on_ice_1);
        }
    }

    protected boolean handleOptionBluSelected() {
    	if (MainActivity.currentTeam == DB.TEAMRED) {
			MainActivity.currentTeam = DB.TEAMBLU;
			return true;
    	} else {
    		return false;
    	}
    }
    
    protected boolean handleOptionRedSelected() {
    	if (MainActivity.currentTeam == DB.TEAMBLU) {
			MainActivity.currentTeam = DB.TEAMRED;
			return true;
		} else {
			return false;
		}
	}

	private void loadPlayer(Player player, int numberID, int firstNameId, int lastNameId, int onIceId) {
    	android.widget.EditText editTextNumber    = (android.widget.EditText) findViewById(numberID);
    	android.widget.EditText editTextFirstName = (android.widget.EditText) findViewById(firstNameId);
    	android.widget.EditText editTextLastName  = (android.widget.EditText) findViewById(lastNameId);
    	android.widget.CheckBox checkBoxOnIce     = (android.widget.CheckBox) findViewById(onIceId);
    	
    	editTextNumber.setText(player.num.toString());
    	editTextFirstName.setText(player.fname);
    	editTextLastName.setText(player.name);
    	checkBoxOnIce.setChecked(player.onIce);
    }

	private void savePlayer(int numberID, int firstNameId, int lastNameId,
			int onIceId) {
		android.widget.EditText editTextNumber = (android.widget.EditText) findViewById(numberID);
		android.widget.EditText editTextFirstName = (android.widget.EditText) findViewById(firstNameId);
		android.widget.EditText editTextLastName = (android.widget.EditText) findViewById(lastNameId);
		android.widget.CheckBox checkBoxOnIce = (android.widget.CheckBox) findViewById(onIceId);

		if (!editTextNumber.getText().toString().isEmpty()
				&& !editTextFirstName.getText().toString().isEmpty()
				&& !editTextLastName.getText().toString().isEmpty()) {

			DB.getInstance().setPlayer(
				Integer.parseInt(editTextNumber.getText().toString()),
				editTextFirstName.getText().toString(),
				editTextLastName.getText().toString(),
				MainActivity.currentTeam,
				checkBoxOnIce.isChecked()
			);
		}
	}

	public void save(android.view.View view) {
		savePlayer(R.id.edit_player_number_1, R.id.edit_player_first_name_1, R.id.edit_player_last_name_1, R.id.check_box_on_ice_1);
		savePlayer(R.id.edit_player_number_2, R.id.edit_player_first_name_2, R.id.edit_player_last_name_2, R.id.check_box_on_ice_2);
		savePlayer(R.id.edit_player_number_3, R.id.edit_player_first_name_3, R.id.edit_player_last_name_3, R.id.check_box_on_ice_3);
		savePlayer(R.id.edit_player_number_4, R.id.edit_player_first_name_4, R.id.edit_player_last_name_4, R.id.check_box_on_ice_4);
		savePlayer(R.id.edit_player_number_5, R.id.edit_player_first_name_5, R.id.edit_player_last_name_5, R.id.check_box_on_ice_5);
	}
}
