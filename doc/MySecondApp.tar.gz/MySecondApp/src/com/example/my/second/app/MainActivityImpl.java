package com.example.my.second.app;

import com.example.my.second.app.DB.DB;

public class MainActivityImpl extends android.app.Activity {
	
	public final static String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";
	private android.view.MenuItem menuItemBluScore = null;
	private android.view.MenuItem menuItemRedScore = null;
	private android.view.MenuItem menuItemPeriod   = null;
	
    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {
    	android.view.MenuInflater inflater = getMenuInflater();
    	inflater.inflate(R.menu.activity_main, menu);
    	
    	menuItemBluScore = menu.findItem(R.id.menu_blu_score);
    	menuItemRedScore = menu.findItem(R.id.menu_red_score);
    	menuItemPeriod   = menu.findItem(R.id.menu_current_game);
    	
    	updateScores();
    	
        return true;
    }
    
    @Override
    protected void onResume() {
    	super.onResume();
    	updateScores();
    }
    
    protected boolean handleOptionBluSelected() { return true; }
    protected boolean handleOptionRedSelected() { return true; }
    protected boolean handleOptionCurrentGameSelected() { return true; }
    
    protected void updateScores() {
    	if (menuItemBluScore != null)
    		menuItemBluScore.setIcon(getBluIconIdFromScore(DB.getInstance().getScore().get(DB.TEAMBLU)));
    	if (menuItemRedScore != null)
    		menuItemRedScore.setIcon(getRedIconIdFromScore(DB.getInstance().getScore().get(DB.TEAMRED)));
    }
    
    protected void updatePeriod() {
    	if (menuItemPeriod != null)
    		menuItemPeriod.setIcon(getPeriodIdFromPeriod(DB.getInstance().getPeriod()));
    }
    
    protected int getBluIconIdFromScore(Integer score) {
    	switch (score.intValue()) {
    		case 0:  return R.drawable.blu0;
    		case 1:  return R.drawable.blu1;
    		case 2:  return R.drawable.blu2;
    		case 3:  return R.drawable.blu3;
    		case 4:  return R.drawable.blu4;
    		case 5:  return R.drawable.blu5;
    		case 6:  return R.drawable.blu6;
    		case 7:  return R.drawable.blu7;
    		case 8:  return R.drawable.blu8;
    		case 9:  return R.drawable.blu9;
    		default: return -1;
    	}
    }
    
    protected int getRedIconIdFromScore(Integer score) {
    	switch (score.intValue()) {
    		case 0:  return R.drawable.red0;
    		case 1:  return R.drawable.red1;
    		case 2:  return R.drawable.red2;
    		case 3:  return R.drawable.red3;
    		case 4:  return R.drawable.red4;
    		case 5:  return R.drawable.red5;
    		case 6:  return R.drawable.red6;
    		case 7:  return R.drawable.red7;
    		case 8:  return R.drawable.red8;
    		case 9:  return R.drawable.red9;
    		default: return -1;
    	}
    }
    
    protected int getPeriodIdFromPeriod(Integer period) {
    	switch (period) {
	    	case 1:  return R.drawable.period1;
	    	case 2:  return R.drawable.period2;
	    	case 3:  return R.drawable.period3;
	    	default: return -1;
    	}
    }
    
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
    	switch (item.getItemId()) {
			case R.id.menu_blu_score: {
				if (handleOptionBluSelected()) {
					android.content.Intent intent = new android.content.Intent(this, MainActivity.class);
					startActivity(intent);
				}
				return true;
			}
			case R.id.menu_red_score: {
				if (handleOptionRedSelected()) {
					android.content.Intent intent = new android.content.Intent(this, MainActivity.class);
					startActivity(intent);
				}
				return true;
			}
    		case R.id.menu_current_game: {
    			if (handleOptionCurrentGameSelected()) {
    				android.content.Intent intent = new android.content.Intent(this, DisplayMessageActivity.class);
    				startActivity(intent);
    			}
    			return true;
    		}
        	default:
        		return super.onOptionsItemSelected(item);
    	}
    }
}